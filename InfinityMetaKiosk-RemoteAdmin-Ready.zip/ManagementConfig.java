package com.infinitymeta.kiosk;

/**
 * Remote management configuration.
 * Set MANAGEMENT_BASE_URL to the HTTPS address of your own management API.
 */
public final class ManagementConfig {
    private ManagementConfig() {}

    public static final String MANAGEMENT_BASE_URL =
            "https://YOUR-MANAGEMENT-SERVER.example/api";

    public static final long POLL_INTERVAL_MS = 30_000L;
    public static final int CONNECT_TIMEOUT_MS = 10_000;
    public static final int READ_TIMEOUT_MS = 15_000;
}
