package com.infinitymeta.kiosk;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;
import java.lang.ref.WeakReference;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Polls the management API for predefined, authenticated commands.
 * There is deliberately no arbitrary shell/ADB execution here.
 */
public final class ManagementCommandService {
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
    private static boolean started;
    private static WeakReference<Activity> activityRef;

    private ManagementCommandService() {}

    public static synchronized void start(Context context) {
        if (context instanceof Activity) {
            activityRef = new WeakReference<>((Activity) context);
        }
        if (started) return;
        started = true;
        Context app = context.getApplicationContext();
        EXECUTOR.execute(() -> {
            ManagementClient client = new ManagementClient(app);
            try { client.register(); } catch (Exception ignored) {}

            while (true) {
                try {
                    String response = client.pollCommands();
                    handleResponse(app, client, response);
                } catch (Exception ignored) {}

                try { Thread.sleep(ManagementConfig.POLL_INTERVAL_MS); }
                catch (InterruptedException e) { Thread.currentThread().interrupt(); return; }
            }
        });
    }

    private static void handleResponse(Context context, ManagementClient client, String response) {
        try {
            JSONArray commands;
            JSONObject root = new JSONObject(response);
            commands = root.optJSONArray("commands");
            if (commands == null) return;

            for (int i = 0; i < commands.length(); i++) {
                JSONObject c = commands.getJSONObject(i);
                String id = c.optString("id", "");
                String action = c.optString("action", "");
                try {
                    execute(context, action, c.optString("message", ""));
                    client.report(id, "success", action);
                } catch (Exception e) {
                    client.report(id, "failed", e.getMessage() == null ? "error" : e.getMessage());
                }
            }
        } catch (Exception ignored) {}
    }

    private static void execute(Context context, String action, String message) {
        if ("PING".equals(action)) return;

        if ("SHOW_MESSAGE".equals(action)) {
            new Handler(Looper.getMainLooper()).post(() ->
                    Toast.makeText(context, message, Toast.LENGTH_LONG).show());
            return;
        }

        Activity activity = activityRef == null ? null : activityRef.get();
        if (activity == null || activity.isFinishing()) return;

        new Handler(Looper.getMainLooper()).post(() -> {
            switch (action) {
                case "ENTER_KIOSK":
                    activity.recreate();
                    break;
                case "EXIT_KIOSK":
                    activity.finishAndRemoveTask();
                    break;
                case "RESTART_KIOSK":
                    Intent i = activity.getPackageManager().getLaunchIntentForPackage(
                            activity.getPackageName());
                    if (i != null) {
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        activity.startActivity(i);
                    }
                    activity.finish();
                    break;
                case "DELETE_APP":
                    requestAuthorizedSelfRemoval(activity);
                    break;
                default:
                    throw new IllegalArgumentException("Unknown management action");
            }
        });
    }

    /**
     * Device Owner apps must deprovision themselves before removal.
     * The server must authorize this command; this method never accepts a shell command.
     */
    private static void requestAuthorizedSelfRemoval(Activity activity) {
        DevicePolicyManager dpm =
                (DevicePolicyManager) activity.getSystemService(Context.DEVICE_POLICY_SERVICE);
        ComponentName admin = new ComponentName(activity, KioskDeviceAdminReceiver.class);

        if (dpm != null && dpm.isDeviceOwnerApp(activity.getPackageName())) {
            try {
                dpm.clearDeviceOwnerApp(activity.getPackageName());
            } catch (SecurityException e) {
                Toast.makeText(activity,
                        "Cannot remove Device Owner automatically on this Android build",
                        Toast.LENGTH_LONG).show();
                return;
            }
        }

        Intent uninstall = new Intent(Intent.ACTION_DELETE);
        uninstall.setData(android.net.Uri.parse("package:" + activity.getPackageName()));
        uninstall.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        activity.startActivity(uninstall);
    }
}
