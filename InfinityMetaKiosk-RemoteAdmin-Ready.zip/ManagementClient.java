package com.infinitymeta.kiosk;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.provider.Settings;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

/** Minimal HTTPS client for the authenticated management API. */
public final class ManagementClient {
    private static final String PREFS = "remote_management";
    private static final String DEVICE_ID = "device_id";
    private static final String DEVICE_TOKEN = "device_token";

    private final Context context;
    private final SharedPreferences prefs;

    public ManagementClient(Context context) {
        this.context = context.getApplicationContext();
        this.prefs = this.context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public String getDeviceId() {
        String id = prefs.getString(DEVICE_ID, null);
        if (id == null) {
            String androidId = Settings.Secure.getString(
                    context.getContentResolver(), Settings.Secure.ANDROID_ID);
            id = "imk-" + (androidId == null ? UUID.randomUUID() : androidId);
            prefs.edit().putString(DEVICE_ID, id).apply();
        }
        return id;
    }

    public String getDeviceToken() {
        String token = prefs.getString(DEVICE_TOKEN, null);
        if (token == null) {
            token = UUID.randomUUID().toString() + UUID.randomUUID();
            prefs.edit().putString(DEVICE_TOKEN, token).apply();
        }
        return token;
    }

    public String pollCommands() throws Exception {
        return request("GET", "/devices/" + urlEncode(getDeviceId()) + "/commands", null);
    }

    public void register() throws Exception {
        String body = "{"
                + "\"deviceId\":\"" + json(getDeviceId()) + "\","
                + "\"token\":\"" + json(getDeviceToken()) + "\","
                + "\"package\":\"com.infinitymeta.kiosk\","
                + "\"version\":\"1.0.5\","
                + "\"model\":\"" + json(Build.MODEL) + "\","
                + "\"android\":\"" + json(Build.VERSION.RELEASE) + "\""
                + "}";
        request("POST", "/devices/register", body);
    }

    public void report(String commandId, String status, String detail) throws Exception {
        String body = "{"
                + "\"commandId\":\"" + json(commandId) + "\","
                + "\"deviceId\":\"" + json(getDeviceId()) + "\","
                + "\"status\":\"" + json(status) + "\","
                + "\"detail\":\"" + json(detail) + "\""
                + "}";
        request("POST", "/devices/report", body);
    }

    private String request(String method, String path, String body) throws Exception {
        if (ManagementConfig.MANAGEMENT_BASE_URL.contains("YOUR-MANAGEMENT-SERVER")) {
            throw new IllegalStateException("Management server URL is not configured");
        }

        URL url = new URL(ManagementConfig.MANAGEMENT_BASE_URL + path);
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(ManagementConfig.CONNECT_TIMEOUT_MS);
        c.setReadTimeout(ManagementConfig.READ_TIMEOUT_MS);
        c.setRequestProperty("Accept", "application/json");
        c.setRequestProperty("Authorization", "Bearer " + getDeviceToken());
        if (body != null) {
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            try (OutputStream out = c.getOutputStream()) {
                out.write(body.getBytes(StandardCharsets.UTF_8));
            }
        }
        int code = c.getResponseCode();
        InputStream stream = code >= 200 && code < 400 ? c.getInputStream() : c.getErrorStream();
        String response = read(stream);
        c.disconnect();
        if (code < 200 || code >= 300) {
            throw new IllegalStateException("HTTP " + code + ": " + response);
        }
        return response;
    }

    private static String read(InputStream in) throws Exception {
        if (in == null) return "";
        StringBuilder b = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) b.append(line);
        }
        return b.toString();
    }

    private static String json(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"")
                .replace("\n", "\\n").replace("\r", "\\r");
    }

    private static String urlEncode(String s) throws Exception {
        return java.net.URLEncoder.encode(s, "UTF-8");
    }
}
